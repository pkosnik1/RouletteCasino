package com.roulette.units;

public enum EFiledColor {
	BLACK, RED;

}
