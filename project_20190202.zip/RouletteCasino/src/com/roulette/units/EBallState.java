package com.roulette.units;

public enum EBallState {
	INIT, ROLL, DOCKED;
}
