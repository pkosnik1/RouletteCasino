package com.roulette.utils;

public final class RulletteConstant {
	public static int FILDNUMBER = 36;
}
