//For making it functional:
//Add a form to place bets (cash, color, number, etc)
//Generate results before hand in JS with form 
//information-> Alter CSS DOM with JQuery based on results (with animation) -> Display Results
//->Update persistent values (total money for example)
//-> Reset to starting state with JS->repeat sequence.

function playGame(DOMResults){
  (function (){
  var routlette = {
    cash:100,
    color:'color',
    roulette_pick:-1,
    user_pick:-1,
    spinning_degrees:-1,
   }
  
  var verdict ={};
    

function setUserGuesses(){
  
}

function calcGameResults(){
  //gen results
  //compare values
  //return final results
}

function updateVerdict(){
  
}

function animate(){
  
  
}
    
animate();
})()};


